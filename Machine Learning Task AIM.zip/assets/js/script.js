$('#btn').click(function(){
    get_resposne($('#text-ar').val())
})

function get_resposne(txt){
    $.ajax({
        type: 'POST',
        url: '/get_resposne',
        data: JSON.stringify({text: txt}),
        contentType: 'application/json',
        success: function(response){
            alert(response)
        }
    })
}

